#include "ray.h"
#include "stm32f4xx_adc.h"
#include "stm32f4xx_gpio.h"

uint16_t adc_data;
int Dist = 0;

void ray_init()
{
        GPIO_InitTypeDef   GPIO_InitStructure;
        ADC_InitTypeDef ADC_InitStructure;
        ADC_CommonInitTypeDef ADC_CommonInitStructure;
        
        //RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
        RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
        
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
        
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;             // ADC123_IN0
        GPIO_Init(GPIOA, &GPIO_InitStructure);
        
        ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
        ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
        ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
        ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
        ADC_CommonInit(&ADC_CommonInitStructure);
        
        ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
        ADC_InitStructure.ADC_ScanConvMode = DISABLE;
        ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;    // ���� ������
        ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
        ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
        ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
        ADC_InitStructure.ADC_NbrOfConversion = 1;
        ADC_Init(ADC1, &ADC_InitStructure);
        
        ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_3Cycles);     // ADC1�� ä��0 ���
        ADC_ITConfig(ADC1, ADC_IT_EOC, ENABLE);             // ADC1 ���ͷ�Ʈ ���
        ADC_Cmd(ADC1, ENABLE);
        ADC_SoftwareStartConv(ADC1);         
}

void ray_result()
{
        if( 2980 < adc_data)                                     Dist = 10; // 10 Cm
        else if(2980 > adc_data && 2048 < adc_data ) Dist = 15; // 15 Cm
        else if(2048 > adc_data && 1588 < adc_data ) Dist = 20; // 20 Cm
        else if(1588 > adc_data && 1324 < adc_data ) Dist = 25; // 25 Cm
        else if(1324 > adc_data && 1132 < adc_data ) Dist = 30; // 30 Cm
        else if(1132 > adc_data && 1020 < adc_data ) Dist = 35; // 35 Cm
        else if(1020 > adc_data &&  896 < adc_data ) Dist = 40; // 40 Cm
        else if( 896 > adc_data &&  800 < adc_data ) Dist = 45; // 45 Cm
        else if( 800 > adc_data &&  752 < adc_data ) Dist = 50; // 50 Cm
        else if( 752 > adc_data &&  684 < adc_data ) Dist = 55; // 55 Cm
        else if( 684 > adc_data &&  656 < adc_data ) Dist = 60; // 60 Cm
        else if( 656 > adc_data &&  604 < adc_data ) Dist = 65; // 65 Cm
        else if( 604 > adc_data &&  464 < adc_data ) Dist = 70; // 70 Cm
        else if( 464 > adc_data &&  440 < adc_data ) Dist = 75; // 75 Cm
        else if( 440 > adc_data )                             Dist = 80; // 80 Cm
        
}

void ADC_IRQHandler(void)
{ 
        if(ADC_GetITStatus(ADC1, ADC_IT_EOC) != RESET) 
        {
                ADC_ClearITPendingBit(ADC1, ADC_IT_EOC);
                adc_data = ADC_GetConversionValue(ADC1);
        }
}