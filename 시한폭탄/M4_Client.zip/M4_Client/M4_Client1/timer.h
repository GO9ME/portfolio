#ifndef __TIMER_H__
#define __TIMER_H__

typedef struct{
        unsigned int min;
        unsigned int sec;
        unsigned int msec;
} TIME;



void timer_init();
void TIM7_IRQHandler(void);
int clock_calc(TIME *Time, int bombFlag);
void timer_set( int min, int sec, TIME* time);

#endif