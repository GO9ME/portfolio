#include "timer.h"
#include "stm32f4xx_tim.h"
#include "wifi.h"
#include "fnd.h"
#include <stdio.h>

volatile unsigned long int t_cnt;
volatile unsigned long systick_count;
volatile unsigned int timer_check = 0;
unsigned long systick_sec;
int guiTimer0Flag = 0;

unsigned int time_val = 0;

unsigned int minute = 0;
unsigned int second = 0;

TIME Time;
void timer_init()
{
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);        //TIM7  
        TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;                       //TIM7
        TIM_TimeBaseStructure.TIM_Prescaler = 84-1;         //(168Mhz/2)/84 = 1MHz(1us)  //1us
        //TIM_TimeBaseStructure.TIM_Period = 10000-1;        //1us * 10000 =  10ms     
        TIM_TimeBaseStructure.TIM_Period = 4000-1;        //1us * 4000 =  4ms     
        TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
        TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
        TIM_TimeBaseInit(TIM7, &TIM_TimeBaseStructure);
        //Ÿ�̸�7�� ���۽�Ų��.
        TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
        TIM_ITConfig(TIM7, TIM_IT_Update, ENABLE);
        TIM_Cmd(TIM7, ENABLE);
        
}

void TIM7_IRQHandler(void)              //4ms
{
        static int fnd_digit=1;
        
        if(TIM_GetITStatus(TIM7, TIM_IT_Update) != RESET)
        {
                TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
                t_cnt++ ;
                guiTimer0Flag=1;
                systick_count++;
                
                if(!(t_cnt%1))  //4ms
                {
                        display_fnd(fnd_digit,time_val);
                        if(fnd_digit == 4)
                                fnd_digit = 1;
                        else
                                fnd_digit++;
                }
                
                if(t_cnt >= 250)             //1s
                {
                        t_cnt = 0;
                        systick_sec++;
                        timer_check = 1;
                        
                }
        }
}

int clock_calc(TIME *Time, int bombFlag)
{
        int result = 1;
        char senddata[100]={0};
        if( timer_check == 1) 
        {
            if ( bombFlag == 1) 
                {
                        Time->sec--;
                        
                        if(Time->sec == 0)                              // if second = 0, second = 60
                        { 
                                Time->sec = 60;
                                Time->min--; 
                                
                                if(Time->min == 0)                          // if minute = 0, minute = 60
                                { 
                                        
                                        if ( Time->sec == 60 )
                                        {
                                                if ( Time->msec == 0 )
                                                {
                                                        minute = 0;
                                                        second = 0;
                                                }
                                        }
                                        
                                }
                        }
                        minute = Time->min;
                        second = Time->sec;
                        time_val = minute * 60 + second;
                }
                else 
                {
                        minute = Time->min;
                        second = Time->sec;
                        time_val = minute * 60 + second;
                }
                timer_check = 0;
        }
        return result;
}

void timer_set( int min, int sec, TIME* Time)
{
        Time->min = min;
        Time->sec = sec;
}
