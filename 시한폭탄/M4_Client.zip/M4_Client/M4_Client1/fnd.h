#ifndef __FND_H__
#define __FND_H__

#define DIGIT1 1
#define DIGIT2 2
#define DIGIT3 3
#define DIGIT4 4

void fnd_init();
void display_fnd(int digit,int val);
void Segment ( int N );
void display_fnd(int digit,int val);
void Delay(const uint32_t Count);

#endif