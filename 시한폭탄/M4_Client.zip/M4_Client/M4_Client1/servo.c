#include <stdint.h>
#include "servo.h"
#include "stm32f4xx_gpio.h"



void servo_init()
{
        GPIO_InitTypeDef   GPIO_InitStructure;
        
        //RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
        
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8; // SERVO 
        GPIO_Init(GPIOB, &GPIO_InitStructure);
        
}
////////////////////////////////////////////////////////////////

int t3_cnt = 0;
int AngleCount = 0;

void timer3_init()
{
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);        //TIM3
        TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;                       //TIM3
        TIM_TimeBaseStructure.TIM_Prescaler = 84-1;         //(168Mhz/2)/840 = 100KHz(10us)
        TIM_TimeBaseStructure.TIM_Period = 100-1;            //100us
        TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
        TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
        TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
        //Ÿ�̸�3�� ���۽�Ų��.
        TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
        TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
        TIM_Cmd(TIM3, ENABLE);
        
}

void TIM3_IRQHandler(void)
{
        if(TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
        {
                TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
                t3_cnt++;
                
                if(t3_cnt <= AngleCount)
                        GPIO_SetBits(GPIOB, GPIO_Pin_8);     // PWM ON Time
                else
                        GPIO_ResetBits(GPIOB, GPIO_Pin_8);  // PWM OFF Time
                if(t3_cnt >= 200) t3_cnt = 0;                      // 20[ms] �ֱ� PWM
        }
}
void Servo(int Angle) 
{
        if (Angle == -90 )
                AngleCount = 23; // PWM ON Time 2.3[ms]
        else if (Angle == 0)
                AngleCount = 15;  // PWM ON Time 1.5[ms]
        else if(Angle == 90)
                AngleCount = 7;   // PWM ON Time 0.7[ms]
}
////////////////////////////////////////////////////////////////
// delay �Լ�
void Delay_motor(const uint32_t Count)
{
        __IO uint32_t index = 0; 
        for(index = (16 * Count); index != 0; index--);
}



void bomb_stop()
{
        for(int i = 0; i <50 ; i++ ) // +90�� ����
        {
                GPIO_SetBits(GPIOB, GPIO_Pin_8);
                Delay_motor(700);    // 0.7[ms]
                
                GPIO_ResetBits(GPIOB, GPIO_Pin_8);;
                Delay_motor(19300);  // 19.3[ms]
        }     
}
/*
void bomb_ing()
{
for(int i = 0; i <50 ; i++ ) // 0�� ����
{
GPIO_SetBits(GPIOB, GPIO_Pin_8);
Delay_motor(1500);      // 1.5[ms]

GPIO_ResetBits(GPIOB, GPIO_Pin_8);;
Delay_motor(18500);     // 18.5[ms]
        }
}
void bomb_bomb()
{
for(int i = 0; i <50 ; i++ ) // -90�� ����
{
GPIO_SetBits(GPIOB, GPIO_Pin_8);
Delay_motor(2300);     // 2.3[ms]

GPIO_ResetBits(GPIOB, GPIO_Pin_8);;
Delay_motor(17700);    // 17.7[ms]
        }
}


*/