/******************************************************************************
USART 1 : wifi
USART2 : printf
MCU   ESP8266 Serial WIFI ���  ��
3.3V                 VCC, CH_PD
GND                  GND

CortexM4            ESP8266 Serial WIFI ���  ��
PORTA9(USART1 TX)             RX  
PORTA10(USART1 RX)             TX
GND                         GND

PORTC0~11 : FND
PORTB0~2 :  COLOR LED (R, G, B ��)
PORTB8 : SERVO ���� 
PORTA0(ADC)   -> PSD  : Infrared ray Sensor

******************************************************************************/
// stm32f4xx�� �� �������͵��� ������ �������
#include "stm32f4xx.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "wifi.h"
#include "uart.h"
#include "ray.h"
#include "servo.h"
#include "color.h"
#include "fnd.h"
#include "timer.h"


//Timer.c
//volatile unsigned long systick_count;
extern volatile unsigned long int t_cnt;
extern unsigned long systick_sec;
extern TIME Time;
extern int guiTimer0Flag;
extern unsigned int time_val;

extern volatile char uart1_rxdata[5][100]; // uart

volatile int adc_flag;
//volatile  uint16_t adc_data=0;  

//ray.c
extern uint16_t adc_data;
extern int Dist;

extern int colorFlag;

//int servoFlag = 0;
extern int AngleCount ;

int rayFlag = 0;

int bombFlag = 0;

#define ARR_CNT 5

void bomb_mode();


int main()
{
        char senddata[100]={0};
        char recvdata[100]={0};
        char *pToken;
        char *pArray[ARR_CNT]={0};
        //int lcdFlag = 0;
        //int fcmCdsFlag = 0;
        //int systick_sec_old;
        int minute = 0;
        int second = 0;
        
        NVIC_InitTypeDef   NVIC_InitStructure;
        
        int i;
        
        RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOB|RCC_AHB1Periph_GPIOC, ENABLE); // A,B,C ��Ʈ Ȱ��ȭ
        
        
        //���ͷ�Ʈ enable �� Priority ����.
        NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
        
        NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x01;
        NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
        NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
        
        NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn;               //TM7
        NVIC_Init(&NVIC_InitStructure);    
        
        NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;               //TM3
        NVIC_Init(&NVIC_InitStructure);    
        
        NVIC_InitStructure.NVIC_IRQChannel = ADC_IRQn;
        NVIC_Init(&NVIC_InitStructure); 
        
        //Timer ����
        timer_init(); 
        
        //Uart ����
        uart_init(); 
        
        //color led ����
        color_init(); 
        color_green();
        
        // ���� ���� ����
        timer3_init();
        servo_init(); 
        bomb_stop();
        //Servo(-90);
        
        
        //���ܼ� ���� ����
        ray_init(); 
        
        //fnd ����
        fnd_init(); 
        
        //WIfi ����
        WIFI_init();
        sprintf(senddata,"[JHJ_M4:PASSWD]");
        WIFI_send(senddata);
        
        /*
        bombFlag = 1; //test��
        timer_set(1,0, &Time);
        */
        while(1)
        {
                
                recvdata[0] = 0;
                
                if(wifi_wait("+IPD","+IPD", 10))  //�������� :  +IPD,6:hello  ������ 0x0a
                {	
                        for(i=0;i<5;i++) 
                        {
                                if(strncmp((char *)uart1_rxdata[i],"+IPD",4)==0) 
                                {
                                        //					sprintf(recvdata,"RECV Data(index:%d,len:%d) : %s\r\n",i,strlen((char *)(uart0_rxdata[i]+8)),uart0_rxdata[i]+8);
                                        //					printf(recvdata);
                                        strcpy(recvdata,(char *)(uart1_rxdata[i]+8));
                                        recvdata[strlen((char *)(uart1_rxdata[i]+8)) - 1] = 0;
                                        printf(recvdata); 
                                        printf("\r\n");
                                }
                        }
                }
                
                //������ ���� ���
                if(recvdata[0] != 0) 
                {
                        
                        pToken = strtok(recvdata,"[@]");
                        i = 0;
                        while(pToken != NULL)
                        {
                                pArray[i] =  pToken;
                                if(i++ >= ARR_CNT)
                                        break;
                                pToken = strtok(NULL,"[@]");
                        }
                        if(!strncmp(pArray[1]," New con",7))
                        {
                                printf("TEST01\r\n");
                                continue;
                        }
                        else  if(!strncmp(pArray[1]," Already",7))
                        {
                                printf("TEST02\r\n");
                                WIFI_init();
                                sprintf(senddata,"[JHJ_M4:PASSWD]\n");
                                WIFI_send(senddata);
                                continue;
                        }
                        //��ź  �ð� �� �ޱ�������������
                        else if(!strncmp(pArray[1],"TIMER",5)) 
                        {
                                minute =  atoi(pArray[2]);
                                second =  atoi(pArray[3]);
                                
                                timer_set(minute,second,&Time);
                                sprintf(senddata,"[%s]%s@%s@%s\n",pArray[0],pArray[1],pArray[2],pArray[3]);
                        }
                        //��ź  ON/OFF �������������
                        else if(!strncmp(pArray[1],"BOMB",4)) 
                        {
                                if(!strncmp(pArray[2],"ON",2)) {
                                        bombFlag = 1;
                                        sprintf(senddata,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
                                }
                                else if(!strncmp(pArray[2],"STOP",4)) {
                                        bombFlag = 0;
                                        sprintf(senddata,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
                                }
                                else if(!strncmp(pArray[2],"FIRE",4)) {
                                        bombFlag = 2;
                                        sprintf(senddata,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
                                }
                                else if(!strncmp(pArray[2],"RESET",5)) {
                                        bombFlag = 0;
                                        timer_set(0,0,&Time);
                                        sprintf(senddata,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
                                }
                                else if(!strncmp(pArray[2],"TIME",4)) {
                                        
                                        //timer_set(0,0,&Time);
                                        sprintf(senddata,"[%s]%2d Min %2d Sec\n",pArray[0], Time.min, Time.sec);
                                }
                        }
                        WIFI_send(senddata);
                        printf(senddata);
                        printf("\r\n");
                }
                /*
                if(adc_flag)
                {
                adc_data = ADC_GetConversionValue(ADC1);
                adc_flag = 0;
        }
                */
                
                
                // ���ܼ� ���� ����
                ray_result();
                if ( bombFlag ==1 )
                {
                        if ( Dist <= 20 )
                        {
                                rayFlag = 1;
                                bombFlag =2;
                                //sprintf(senddata,"[%s]%s \r\n","[JHJ_SMP]","BOMB BOMB BOMB");
                        }
                }
                //��ź üũ
                //printf("TEST02 %d \r\n", bombFlag);
                bomb_mode();
               
                
                //��ź �������������
                if(guiTimer0Flag)
                {
                        //bomb active��������������
                        if ( bombFlag == 1) 
                        {
                                clock_calc(&Time, bombFlag);
                                if ( time_val == 0 )
                                {
                                        bombFlag = 2;
                                        //sprintf(senddata,"[%s]%s \r\n","[JHJ_SMP]","BOMB BOMB BOMB");
                                        //servoFlag = 2;
                                        //bomb_bomb();
                                }
                                
                        } 
                        else 
                        {
                                clock_calc(&Time, bombFlag);
                        }
                        guiTimer0Flag = 0;
                }
                
                 
        }       //while
}       //main

void bomb_mode()
{
        if ( bombFlag == 2 )
        {
                //printf("TEST03\r\n");
                colorFlag = 2;
                //servoFlag ==2;
                Servo(-90);
        }
        if ( bombFlag == 1) 
        {
                //printf("TEST04\r\n");
                colorFlag = 1;
                //servoFlag == 1;
                Servo(0);
                
        }
        if ( bombFlag == 0) 
        {
                //printf("TEST05\r\n");
                colorFlag = 0;
                //servoFlag = 0;
                Servo(90);
        }   
        color_select();
}



