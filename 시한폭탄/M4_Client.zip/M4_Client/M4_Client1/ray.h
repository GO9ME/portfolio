#ifndef __RAY_H__
#define __RAY_H__

void ADC_IRQHandler(void);
void ray_init();
void ray_result();

#endif