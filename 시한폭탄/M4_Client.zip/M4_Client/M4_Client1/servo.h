#ifndef __SERVO_H__
#define __SERVO_H__
void servo_init();
void Delay_motor(const uint32_t Count);
void bomb_stop();
//void bomb_ing();
//void bomb_bomb();
void timer3_init();
void TIM3_IRQHandler(void);
void Servo(int Angle);
#endif