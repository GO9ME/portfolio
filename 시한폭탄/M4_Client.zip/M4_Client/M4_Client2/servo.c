#include <stdint.h>
#include "servo.h"
#include "stm32f4xx_gpio.h"

void servo_init()
{
        GPIO_InitTypeDef   GPIO_InitStructure;
        
        //RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
        
        GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
        GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
        GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
        GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
        GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8; // SERVO
        GPIO_Init(GPIOB, &GPIO_InitStructure);
}

// delay �Լ�
void Delay_motor(const uint32_t Count)
{
        __IO uint32_t index = 0; 
        for(index = (16 * Count); index != 0; index--);
}
void bomb_stop()
{
        for(int i = 0; i <50 ; i++ ) // +90�� ����
        {
                GPIO_SetBits(GPIOB, GPIO_Pin_8);
                Delay_motor(700);    // 0.7[ms]
                
                GPIO_ResetBits(GPIOB, GPIO_Pin_8);;
                Delay_motor(19300);  // 19.3[ms]
        }     
}
void bomb_ing()
{
        for(int i = 0; i <50 ; i++ ) // 0�� ����
        {
                GPIO_SetBits(GPIOB, GPIO_Pin_8);
                Delay_motor(1500);      // 1.5[ms]
                
                GPIO_ResetBits(GPIOB, GPIO_Pin_8);;
                Delay_motor(18500);     // 18.5[ms]
        }
}
void bomb_bomb()
{
        for(int i = 0; i <50 ; i++ ) // -90�� ����
        {
                GPIO_SetBits(GPIOB, GPIO_Pin_8);
                Delay_motor(2300);     // 2.3[ms]
                
                GPIO_ResetBits(GPIOB, GPIO_Pin_8);;
                Delay_motor(17700);    // 17.7[ms]
        }
}

