/******************************************************************************
USART 1 : wifi
USART2 : printf
MCU   ESP8266 Serial WIFI ���  ��
3.3V                 VCC, CH_PD
GND                  GND

CortexM4            ESP8266 Serial WIFI ���  ��
PORTA9(USART1 TX)             RX  
PORTA10(USART1 RX)             TX
GND                         GND

PORTC0~11 : FND
PORTB0~2 :  COLOR LED (R, G, B ��)
PORTB8 : SERVO ���� 
PORTA0(ADC)   -> PSD  : Infrared ray Sensor

******************************************************************************/
// stm32f4xx�� �� �������͵��� ������ �������
#include "stm32f4xx.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "wifi.h"
#include "uart.h"
#include "color.h"
#include "fnd.h"
#include "timer.h"
#include "exti.h"
#include "LCD.h"


// delay �Լ�
void Delay(const uint32_t Count)
{
  __IO uint32_t index = 0; 
  for(index = (16800 * Count); index != 0; index--);
}


//Timer.c
//volatile unsigned long systick_count;
extern volatile unsigned long int t_cnt;
extern unsigned long systick_sec;

extern volatile char uart1_rxdata[5][100]; // uart


volatile int adc_flag;
//volatile  uint16_t adc_data=0;  

//ray.c
extern uint16_t adc_data;
extern int Dist;

#define ARR_CNT 5

volatile int count = 0 ;

int sec = 0;
int min = 0;
int push_flag = 0;
int LCD_flag = 0;


int main()
{
          char senddata[100]={0};
          char recvdata[100]={0};
          char *pToken;
          char *pArray[ARR_CNT]={0};
          //int lcdFlag = 0;
          //int fcmCdsFlag = 0;
          //int systick_sec_old;
          
          NVIC_InitTypeDef   NVIC_InitStructure;
          
          int i;
          int key = 0;
          int key_old= 0;
          
          RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOB|RCC_AHB1Periph_GPIOC, ENABLE); // A,B,C ��Ʈ Ȱ��ȭ
          RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);        //TIM7  
          
          //���ͷ�Ʈ enable �� Priority ����.
          NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
          
          NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
          NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x01;
          NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
          NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
          NVIC_Init(&NVIC_InitStructure);
          
          NVIC_InitStructure.NVIC_IRQChannel = EXTI1_IRQn;
          NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01; 
          NVIC_Init(&NVIC_InitStructure);
          
          NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
          NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01; 
          NVIC_Init(&NVIC_InitStructure);
          
          NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
          NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01; 
          NVIC_Init(&NVIC_InitStructure);
          
          NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
          NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01; 
          NVIC_Init(&NVIC_InitStructure);
          
          NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
          NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01; 
          NVIC_Init(&NVIC_InitStructure);
          NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x01;
          NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;
          NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
          
          NVIC_InitStructure.NVIC_IRQChannel = TIM7_IRQn;               //TM7
          NVIC_Init(&NVIC_InitStructure);    
          
          NVIC_InitStructure.NVIC_IRQChannel = ADC_IRQn;
          NVIC_Init(&NVIC_InitStructure); 
          
          exti_init();
          
          Port_Init();
          Init_LCD();

          
          //Timer ����
          timer_init(); 
          
          //Uart ����
          uart_init(); 
          
          //color led ����
          color_init(); 
          color_green();
          
          //fnd ����
          fnd_init(); 
          
          //WIfi ����
          WIFI_init();
          sprintf(senddata,"[JJI_M4:PASSWD]");
          WIFI_send(senddata);
          
          
          while(1)
          {
                    
              
            
                    recvdata[0] = 0;
                    if(wifi_wait("+IPD","+IPD", 10))  //�������� :  +IPD,6:hello  ������ 0x0a
                    {	
                              for(i=0;i<5;i++) 
                              {
                                        if(strncmp((char *)uart1_rxdata[i],"+IPD",4)==0) 
                                        {
                                                  //					sprintf(recvdata,"RECV Data(index:%d,len:%d) : %s\r\n",i,strlen((char *)(uart0_rxdata[i]+8)),uart0_rxdata[i]+8);
                                                  //					printf(recvdata);
                                                  strcpy(recvdata,(char *)(uart1_rxdata[i]+8));
                                                  recvdata[strlen((char *)(uart1_rxdata[i]+8)) - 1] = 0;
                                                  printf(recvdata); 
                                                  printf("\r\n");
                                        }
                              }
                    }
                    if(recvdata[0] != 0) {
                              
                              pToken = strtok(recvdata,"[@]");
                              i = 0;
                              while(pToken != NULL)
                              {
                                        pArray[i] =  pToken;
                                        if(i++ >= ARR_CNT)
                                                  break;
                                        pToken = strtok(NULL,"[@]");
                              }
                              if(!strncmp(pArray[1]," New con",7))
                              {
                                        printf("TEST01\r\n");
                                        continue;
                              }
                              else  if(!strncmp(pArray[1]," Already",7))
                              {
                                        printf("TEST02\r\n");
                                        WIFI_init();
                                        sprintf(senddata,"[JJI_M4:PASSWD]");
                                        WIFI_send(senddata);
                                        continue;
                              }
                              /*
                              else if(!strncmp(pArray[1],"LIGHT_ON",8))
                              {
                              GPIO_SetBits(GPIOB, GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|
                              GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15); 
                    }
                              else if(!strncmp(pArray[1],"LIGHT_OFF",9))
                              {
                              GPIO_ResetBits(GPIOB, GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|
                              GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);
                    }
                              */
                              /*
                              else if(!strncmp(pArray[1],"LED",3))
                              {
                              temp=strtol(pArray[2],0,16)&0xff;
                              sprintf(senddata,"Recv : %d\n",temp);
                              printf(senddata);
                              printf("\r\n");
                              
                              GPIO_Write(GPIOC,temp); 
                              sprintf(senddata,"[%s]%s#%s\n",pArray[0],pArray[1],pArray[2]);
                              WIFI_send(senddata);
                              printf(senddata);
                              printf("\r\n");
                              
                    }
                              
                              else if(!strncmp(pArray[1],"GETCDS",6))
                              {
                              lcdFlag = 1;
                    }
                              else if(!strncmp(pArray[1],"OFFCDS",6))
                              {
                              lcdFlag = 0;
                    }
                              
                              else if(!strncmp(pArray[1],"LED",3)) {
                              if(!strncmp(pArray[2],"ON",2)) {
                              GPIO_SetBits(GPIOB,GPIO_Pin_8);
                              sprintf(senddata,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
                    }
                              else if(!strncmp(pArray[2],"OFF",3)) {
                              GPIO_ResetBits(GPIOB,GPIO_Pin_8);
                              //GPIO_ToggleBits(GPIOB,GPIO_Pin_8);
                              sprintf(senddata,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
                    }
                    } else if(!strncmp(pArray[1],"LAMP",4)) {
                              if(!strncmp(pArray[2],"ON",2)) {
                              GPIO_SetBits(GPIOB,GPIO_Pin_9);
                              sprintf(senddata,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
                    }
                              else if(!strncmp(pArray[2],"OFF",3))
                              {
                              GPIO_ResetBits(GPIOB,GPIO_Pin_9);
                              sprintf(senddata,"[%s]%s@%s\n",pArray[0],pArray[1],pArray[2]);
                    }
                    }else if(!strncmp(pArray[1],"GETSTATE",strlen("GETSTATE"))) {
                              if(!strncmp(pArray[2],"DEV",3)) {
                              sprintf(senddata,"[%s]DEV@%s@%s\n",pArray[0], GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_8)?"ON":"OFF",GPIO_ReadOutputDataBit(GPIOB,GPIO_Pin_9)?"ON":"OFF");
                    }
                    }
                              else if(!strncmp(pArray[1],"GETSENSOR",9)) {
                              //                 if(pArray[2] != NULL) {
                              //                  sensorTime = atoi(pArray[2]);
                              //                       sprintf(senddata,"[%s]%s@%u\n",pArray[0],pArray[1],adc_data);
                              //             } else {
                              //                       sensorTime = 0;
                              //                         pArray[2][strlen(pArray[2])-1] = '\0';
                              sprintf(senddata,"[%s]%s@%u@%lu@%d\n",pArray[0],pArray[1],adc_data,systick_sec,50);
                              //           }
                              //                  strcpy(getSensorId,pArray[2]);
                    }         
                              
                              
                              //          else
                              {
                              //            sprintf(senddata,"[%s]%s\n",pArray[0],pArray[1]);
                              WIFI_send(senddata);
                              printf(senddata);
                              printf("\r\n");
                    }
                              */
                              
                    }
                    
                    key = GPIO_ReadInputData(GPIOA)&0x00FF;
                    
                    if ( key != key_old )
                    {
                              key_old = key;
                                        
                              
                          if(push_flag == 0)
                              {clrscr();
                                 if ( key == 0x01) // Bt1
                                {
                                       push_flag = 1;
                                }
                                else if ( key == 0x02) // Bt2
                                {
                                        
                                       push_flag = 2;
                                }
                                else if ( key == 0x04) // Bt3
                                {
                                       push_flag = 3;
                                }
                                else if ( key == 0x08) // Bt4
                                {
                                       push_flag = 4;
                                }
                                else if ( key == 0x10) // Bt5
                                {
                                       push_flag = 5;
                                }
                                else push_flag = 0;
                              }
                          if(push_flag == 1)
                          {clrscr();
                                if ( key == 0x20) // Bt6
                                {
                                        if(sec>=60)
                                        {
                                          sec = 0;
                                        }
                                        else sec += 10;
                                }
                                else if ( key == 0x40) // Bt7
                                      {
                                              min += 1;
                                      }
                                else if ( key == 0x80) // Bt8, ���θ޴��� ���� �ϴ� �κ�
                                      {
                                            push_flag = 0;
                                      }
                          }
                          if(push_flag == 2)
                          {
                            
                                sprintf(senddata,"[JHJ_M4]TIMER@%d@%d\n\r",min,sec);
                                WIFI_send(senddata);
                                clrscr();
                                if ( key == 0x80) // Bt8, ���θ޴��� ���� �ϴ� �κ�
                                {
                                      push_flag = 0;
                                }
                            
                          }
                         if(push_flag == 3)
                         {clrscr();
                                sprintf(senddata,"[JHJ_M4]BOMB@ON\r\n");
                                WIFI_send(senddata);
                                if ( key == 0x80) // Bt8, ���θ޴��� ���� �ϴ� �κ�
                                {
                                      push_flag = 0;
                                }
                          }
                         if(push_flag == 4)
                         {clrscr();
                                sprintf(senddata,"[JHJ_M4]BOMB@STOP\r\n");
                                WIFI_send(senddata);
                                if ( key == 0x80) // Bt8, ���θ޴��� ���� �ϴ� �κ�
                                {
                                      push_flag = 0;
                                }
                         }
                         if(push_flag == 5)
                         {clrscr();
                                sprintf(senddata,"[JHJ_M4]BOMB@FIRE\r\n");
                                WIFI_send(senddata);
                                if ( key == 0x80) // Bt8, ���θ޴��� ���� �ϴ� �κ�
                                {
                                      push_flag = 0;
                                }
                         }
                         
                   }
                    
                                   
                    
                    
                    if(push_flag == 0)
                    {
                         
                          sprintf(senddata,"Main menu");
                          lcd(0,0,senddata);    // ���ڿ� ���
                    }
                    else if(push_flag == 1)
                    {
                          
                          sprintf(senddata,"Time Setting");
                          lcd(0,0,senddata);    // ���ڿ� ���
                          sprintf(senddata,"%dmin : %dsec", min, sec);
                          lcd(0,1,senddata);    // ���ڿ� ���
                          
                    }
                    else if(push_flag == 2)
                    {
                       
                          sprintf(senddata,"TimeSend");
                          lcd(0,0,senddata);    // ���ڿ� ���
                          sprintf(senddata,"TimeSend");
                          lcd(0,1,senddata);    // ���ڿ� ���
                          
                    }
                    else if(push_flag == 3)
                    {
                        
                          sprintf(senddata,"WANINIGWANINIG");
                          lcd(0,0,senddata);    // ���ڿ� ���
                          sprintf(senddata,"WANINIGWANINIG");
                          lcd(0,1,senddata);    // ���ڿ� ���
                          
                    }
                    else if(push_flag == 4)
                    {
                          
                          sprintf(senddata,"STOPSTOPSTOP");
                          lcd(0,0,senddata);    // ���ڿ� ���
                          sprintf(senddata,"STOPSTOPSTOP");
                          lcd(0,1,senddata);    // ���ڿ� ���
                          
                    }
                    else if(push_flag == 5)
                    {
                        
                          sprintf(senddata,"BOMBBOMB!!!!!!!");
                          lcd(0,0,senddata);    // ���ڿ� ���
                          sprintf(senddata,"BOMBBOMB!!!!!!!");
                          lcd(0,1,senddata);    // ���ڿ� ���
                          
                    }
                    
                          
                    
                    
                    
                    
          
                    
          } 
                  
          
               
                    
                    
                    
}



