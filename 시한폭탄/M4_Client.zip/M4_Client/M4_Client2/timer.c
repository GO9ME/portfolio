#include "timer.h"
#include "stm32f4xx_tim.h"

volatile unsigned long int t_cnt;
volatile unsigned long systick_count;
unsigned long systick_sec;

void timer_init()
{
        TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;                       //TIM7
        TIM_TimeBaseStructure.TIM_Prescaler = 84-1;         //(168Mhz/2)/84 = 1MHz(1us)  //1us
        // TIM_TimeBaseStructure.TIM_Period = 10000-1;        //1us * 10000 =  10ms     
        TIM_TimeBaseStructure.TIM_Period = 4000-1;        //1us * 4000 =  4ms     
        TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
        TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
        TIM_TimeBaseInit(TIM7, &TIM_TimeBaseStructure);
        //Ÿ�̸�7�� ���۽�Ų��.
        TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
        TIM_ITConfig(TIM7, TIM_IT_Update, ENABLE);
        TIM_Cmd(TIM7, ENABLE);
}

void TIM7_IRQHandler(void)              //4ms
{
        static int fnd_digit=1;
        
        
        if(TIM_GetITStatus(TIM7, TIM_IT_Update) != RESET)
        {
                TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
                t_cnt++ ;
                systick_count++;
                
                if(!(t_cnt%1))  //4ms
                {
                        //display_fnd(fnd_digit,adc_data);
                        if(fnd_digit == 4)
                                fnd_digit = 1;
                        else
                                fnd_digit++;
                }
                if(t_cnt >= 250)             //1s
                {
                        t_cnt = 0;
                        systick_sec++;
                        //      flag_1sec=1;
                        //      printf("TEST01 TIM7\r\n");      
                }
        }
}

