#ifndef __TIMER_H__
#define __TIMER_H__

void timer_init();
void TIM7_IRQHandler(void);

#endif