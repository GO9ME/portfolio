#ifndef __LCD_H_
#define __LCD_H_

#include "stm32f4xx.h"

#define TLCD_RS  GPIO_Pin_0                  // LCD RS ��ȣ 
#define TLCD_RW  GPIO_Pin_1                  // LCD RW ��ȣ 
#define TLCD_E   GPIO_Pin_2                  // LCD E ��ȣ 
#define TLCD_EN { GPIO_ResetBits(GPIOB, TLCD_E); GPIO_SetBits(GPIOB, TLCD_E); }
#define DATA     GPIOC                       // LCD ������ ��ȣ 

#define ON      1
#define OFF     2

#define RIGHT   1
#define LEFT    2

//void Delay(const uint32_t Count);

void Delay_us(const uint32_t Count);

void Port_Init(void);

void E_Pulse(void);

void TLCD_DATA(unsigned char data);

void Func_Set(void);

void Init_LCD(void);

void lcd_char(char s);

void lcd_disp(char x, char y);

void move_disp(char p );

void disp_ON_OFF(char d, char c, char b);

void clrscr(void);

void lcd(char x, char y, char *str);



#endif
