#ifndef __COLOR_H__
#define __COLOR_H__
void color_init();
void color_red();
void color_green();
void color_yellow();

#endif 