﻿/*
 * global.h
 *
 * Created: 2018-12-07 오후 2:27:09
 *  Author: auto
 */ 


#ifndef GLOBAL_H_
#define GLOBAL_H_

#define BUFSIZE 100

#endif /* GLOBAL_H_ */