﻿/*
 * timer.h
 *
 * Created: 2018-12-07 오후 2:29:08
 *  Author: auto
 */ 


#ifndef TIMER_H_
#define TIMER_H_

void TIMER0_init();
extern void display_fnd(int,int);
#endif /* TIMER_H_ */