/*
* esp8266 wifi module
*
* Created: 2018-11-19 오후 12:15:14
* Author : 서울기술교육센터 KSH
*/

//#define F_CPU 16000000
#define F_CPU 14745600
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "global.h"
#include "wifi.h"
#include "uart.h"
#include "lcd.h"

#define MOTOR_DDR DDRB
#define MOTOR_PORT PORTB      //PB4(OC0) PWM   : Dc motor M_EN
#define MOTOR_LEFT_ENABLE PB2   //  Dc motor M_D1
#define MOTOR_RIGHT_ENABLE PB3  //  Dc motor M_D2

FILE OUTPUT = FDEV_SETUP_STREAM((void *)UART0_transmit, NULL, _FDEV_SETUP_WRITE);

#define bit_set(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
#define bit_clear(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))

unsigned char key_input();

extern volatile unsigned long systick_count;
extern volatile unsigned long systick_sec;

void TIMER0_init();
void led_control();
void fan_control();
void motor_control();

#define ARR_CNT 7

extern volatile int rx0flag;
extern volatile int rx1flag;
extern int connect_flag;
extern char uart1_rxdata[5][BUFSIZE];

int fan_state = 0; // 0일때 비활성 1일때 활성
int auto_mode = 0; // 0일때 비활성 1일때 활성
int home_mode = 0; // 0일때 비활성 1일때 활성
int temp_val;
int cds_val;

int main(void)
{
	/* Replace with your application code */
	int i;
	int key;
	int serverflag = 0;
	int sensorTime = 0;
	
	unsigned long systick_sec_old=0;
	char *pToken;
	char *pArray[ARR_CNT]={0};
	char senddata[100]={0};
	char recvdata[100]={0};
	char getSensorId[20]={0};
	
	char lcdLine1[17]="SMART HOME HS";
	char lcdLine2[17]="SERVICE SYSTEM";
	
	DDRA = 0x0f;		//PA0~PA3 : LED
	PORTA = 0xf0;       //PA4~PA7 : KEY(internal pull up)
	
	TIMER0_init();		//250Hz timer0
	
	UART0_init();
	UART1_init();
	
	Port_Init();	//LCD 포트 활성화
	Init_LCD();		//LCD 실행
	
	
	stdout=&OUTPUT;
	
	int duty = 50;
	//int old_duty = duty;   //duty:50%
	int ocr0=0;
	
	//FAN
	DDRF = 0x01;
	PORTF = 0x00;
	
	MOTOR_DDR = 0xff;
	MOTOR_PORT = 0x00;
	
	//PORTF = 0x01;
	
	clrscr();  //  화면 클리어
	
	lcd(0,0,lcdLine1); // 문자열 출력
	lcd(0,1,lcdLine2); // 문자열 출력
	
	UART0_string("main start!!\r\1n");

	sei(); //global interrupt enable

	WIFI_init();
	
	
	ocr0 = (256/100.0) * duty;
	if(ocr0 >= 256)
	ocr0=255;
	OCR0 = ocr0;
	
	while (1)
	{
		
		/*
		if(duty != old_duty)
		{
		ocr0 = (256/100.0) * duty;

		if(ocr0 <= 0)
		{
		bit_clear(TCCR0,COM01); //GPIO PB4
		bit_clear(PORTB,PB4);
		}
		else if(ocr0 >= 256)
		ocr0=255;
		else
		bit_set(TCCR0,COM01); //GPIO PB4 PWM
		
		
		OCR0 = ocr0;
		//lcd_print();
		old_duty = duty;
		}
		
		*/
		memset(recvdata, 0, sizeof(recvdata));
		//		printf("TEST00 %lu\r\n",systick_sec);
		key = key_input(); //sw0:1, sw1:2, sw2:3, sw3:4
		
		if(key != 0)
		{
			if ( key == 1)	//현관문 열기
			{
				sprintf(senddata,"[%s]%s\n", "[HS_ARD]","DOOR@OPEN");
				//WIFI_send(senddata);
			}
			if ( key == 2)	//현관문 닫기
			{
				sprintf(senddata,"[%s]%s\n", "[HS_ARD]","DOOR@CLOSE");
				//WIFI_send(senddata);
			}
			if ( key == 3) // 자동 절전 모드
			{
				sprintf(senddata,"[%s]%s\n", "[HS_ARD]","GETSENSOR@5");
				//WIFI_send(senddata);
				auto_mode = 1;
				
				strcpy(lcdLine2,"ECO MODE ON");
				
			}
			if ( key == 4) // 절전 모드 해제
			{
				sprintf(senddata,"[%s]%s\n", "[HS_ARD]","GETSENSOR");
				//WIFI_send(senddata);
				auto_mode = 0;
				
				strcpy(lcdLine2,"ECO MODE OFF");
			}
			
			printf("Key %d\r\n",key);
			//fndnum = key;
		}
		/*
		if(rx0flag)
		;
		*/
		
		if(wifi_wait("+IPD","+IPD", 25UL))  //수신포멧 :  +IPD,6:[ID]hello  끝문자 0x0a
		{
			for(i=0;i<5;i++)
			{
				if(!strncmp("+IPD",uart1_rxdata[i],4))
				{
					strcpy(recvdata,uart1_rxdata[i]);
					printf(recvdata); printf("\r");
					uart1_rxdata[i][0]='\0';
					break;
				}
			}
		}

		if(recvdata[0] != 0)
		{
			pToken = strtok(recvdata,",:[@]");
			i = 0;
			while(pToken != NULL)
			{
				pArray[i] =  pToken;
				//				printf("pA(%d) : %s\r\n",i ,pArray[i]);
				if(++i >= ARR_CNT)
				break;
				pToken = strtok(NULL,",:[@]");
			}
			
			if(i < ARR_CNT)
			pArray[i] = NULL;
			//pArray[0] : +IPD
			//pArray[1] : 문자열 길이
			//pArray[2] : 송신 ID
			//pArray[3] : 송신 문자열
			
			sprintf(senddata,"[%s]%s",pArray[2],pArray[3]);
			
			if(!strncmp(pArray[3]," New con",7))
			{
				serverflag = 1;
				recvdata[0] = 0;
				continue;
			}
			if(!strncmp(pArray[3]," Already logged!",7) ||!strncmp(pArray[3]," Authentication",7) )
			{
				serverflag = 0;
				connect_flag = 0;
				WIFI_init();
				continue;
			}
			
			
			if(!strncmp(pArray[3],"GETSTATE",strlen("GETSTATE")))
			{
				if(!strncmp(pArray[4],"DEV",3))
				{
					sprintf(senddata,"[%s]DEV@%s@%s\n",pArray[2],(PORTA & 0x01)?"ON":"OFF",(PORTA & 0x02)?"ON":"OFF");
				}
			}
			
			/************************************************************************/
			/*   위험상황 받아오기                                                    */
			/************************************************************************/
			
			else if(!strncmp(pArray[3],"HOMEMODE",8))	//앱에서 컨트롤
			{
				if(!strncmp(pArray[4],"WARNING",7))
				{
					home_mode = 1;
					strcpy(lcdLine1,"WARNING!!");
					sprintf(senddata,"[%s]%s@%s\r\n",pArray[2],pArray[3],pArray[4]);
					motor_control();
				}
				else if (!strncmp(pArray[4],"SAFE",3))
				{
					home_mode = 0;
					strcpy(lcdLine1,"SAFE HOME");
					sprintf(senddata,"[%s]%s@%s\r\n",pArray[2],pArray[3],pArray[4]);
					motor_control();
				}
			}
			if ( !home_mode)
			{
				
				
				/************************************************************************/
				/*   에코모드 받아오기                                                    */
				/************************************************************************/
				
				if(!strncmp(pArray[3],"ECOMODE",7))	//앱에서 컨트롤
				{
					if(!strncmp(pArray[4],"ON",2))
					{
						auto_mode = 1;
						strcpy(lcdLine1,"ECO MODE ON");
						sprintf(senddata,"[%s]%s\n", "[HS_ARD]","GETSENSOR@5");
					}
					else if (!strncmp(pArray[4],"OFF",3))
					{
						auto_mode = 0;
						strcpy(lcdLine1,"ECO MODE OFF");
						sprintf(senddata,"[%s]%s\n", "[HS_ARD]","GETSENSOR");
						sensorTime = 0;
					}
				}
				
				/************************************************************************/
				/*  센서값 받아오기                                                      */
				/************************************************************************/
				
				else if(!strncmp(pArray[3],"GETSENSOR",9))
				{
					if (!sensorTime){
						if(pArray[4] != NULL)
						{
							//sensorTime = atoi(pArray[4]);
							cds_val = atoi(pArray[4]);	// 조도값 저장
							temp_val = atoi(pArray[5]);	// 온도값 저장
						
							sprintf(senddata,"[%s]%s@%s@%s@%s\n",pArray[2],pArray[3],pArray[4],pArray[5],pArray[6]);
							sprintf(lcdLine2,"C:%02d T:%02d H:%02d",cds_val,temp_val,atoi(pArray[6]));
						
						}
						/*
						else
						{
							sensorTime = 0;
							pArray[3][strlen(pArray[3])-1] = '\0';
							sprintf(senddata,"[%s]%s@%d@%ld\n",pArray[2],pArray[3],10,systick_sec);
						}
						*/
					}
					//strcpy(getSensorId,pArray[2]);
				}
				
				/************************************************************************/
				/*  에어콘 제어                                                          */
				/************************************************************************/
				
				else if(!strncmp(pArray[3],"FAN",3))
				{
					if(!strncmp(pArray[4],"ON",2))
					{
						fan_state = 1;
						PORTF = bit_set(PORTF,PORTF0);
					}
					else if (!strncmp(pArray[4],"OFF",3))
					{
						fan_state = 0;
						PORTF = bit_clear(PORTF,PORTF0);
					}
					sprintf(senddata,"[%s]%s@%s\r\n",pArray[2],pArray[3],pArray[4]);
				}
				
				/************************************************************************/
				/*  LED 제어                                                             */
				/************************************************************************/
				
				else if(!strncmp(pArray[3],"ON_LAMP",7))	//전체 등제어
				
				{
					PORTA |= 0x0f; //led on
					strcpy(senddata,pArray[4]);
					senddata[3] = '\0';
					//fndnum = atoi(senddata);
					sprintf(senddata,"[%s]%s\r\n",pArray[2],pArray[3]);
				}
				
				else if(!strncmp(pArray[3],"OFF_LAMP",8))	// 전체 등제어
				{
					PORTA &= ~0x0f; //led off
					strcpy(senddata,pArray[4]);
					senddata[3] = '\0';
					//fndnum = atoi(senddata);
					sprintf(senddata,"[%s]%s\r\n",pArray[2],pArray[3]);
				}
				
				if(!strncmp(pArray[3],"LED",3))
				{
					if(!strncmp(pArray[4],"ON",2)) {
						if (!strncmp(pArray[5],"1",1))	//거실
						{
							PORTA |= 0x01;
						}
						if (!strncmp(pArray[5],"2",1))	//부엌
						{
							PORTA |= 0x02;
						}
						if (!strncmp(pArray[5],"3",1))	//화장실
						{
							PORTA |= 0x04;
						}
						if (!strncmp(pArray[5],"4",1))	//현괄
						{
							PORTA |= 0x08;
						}
						sprintf(senddata,"[%s]%s@%s@%s",pArray[2],pArray[3],pArray[4],pArray[5]);
					}
					else if(!strncmp(pArray[4],"OFF",3))
					{
						if (!strncmp(pArray[5],"1",1))	//거실
						{
							bit_clear(PORTA, PORTA0);
						}
						if (!strncmp(pArray[5],"2",1))	//부엌
						{
							bit_clear(PORTA, PORTA1);
						}
						if (!strncmp(pArray[5],"3",1))	//화장실
						{
							bit_clear(PORTA, PORTA2);
						}
						if (!strncmp(pArray[5],"4",1))	//현괄
						{
							bit_clear(PORTA, PORTA3);
						}
						//PORTA &= ~0x01;
						sprintf(senddata,"[%s]%s@%s@%s",pArray[2],pArray[3],pArray[4],pArray[5]);
					}
				}
			}	//homemode safe
			
			

			if(serverflag)
			{
				WIFI_send(senddata);
				clrscr();  //  화면 클리어
				lcd(0,0,lcdLine1); // 문자열 출력
				lcd(0,1,lcdLine2); // 문자열 출력
			}

		}//Recvdata
		
		
		if(sensorTime!= 0 && !(systick_sec % sensorTime ) && (systick_sec_old != systick_sec))	//2sec
		{
			
			//			sprintf(senddata,"[%s]%lu\r\n",pArray[2],systick_sec);
			//			sprintf(senddata,"[20]%lu\r\n",systick_sec);
			sprintf(senddata,"[%s]SENSOR@%lu@20@30\r\n",getSensorId,systick_sec);
			WIFI_send(senddata);
		}
		
		
		if(systick_sec_old != systick_sec)
		{
			
			/*
			if(DHT_Read(&dhtInfo)) {
			printf("humi: %d.%d, temp:%d.%d\r\n\n",dhtInfo.data[0],dhtInfo.data[1],dhtInfo.data[2],dhtInfo.data[3]);
			}
			*/
			//CDS_start();
			systick_sec_old = systick_sec;
		}
		
		
		/*
		if((cdsValue > 350) && (fcmCdsFlag == 0))
		{
		fcmCdsFlag = 1;
		sprintf(senddata,"[FCMSEND]LAMP_ON@%d\n",cdsValue);
		WIFI_send(senddata);
		printf(senddata); printf("\r");
		}
		else if((cdsValue <= 350) && (fcmCdsFlag == 1))
		{
		fcmCdsFlag = 0;
		sprintf(senddata,"[FCMSEND]LAMP_OFF@%d\n",cdsValue);
		WIFI_send(senddata);
		printf(senddata); printf("\r");
		}
		*/
		
		
		fan_control();
		led_control();
		
		
		
	} //while
}

unsigned char key_input(void)			/* input key KEY1 - KEY4 */
{
	static unsigned char key_flag = 0;
	unsigned char key;
	key = PINA & 0xf0;				// any key pressed ?
	if(key == 0x00)					// if no key, check key off
	{
		if(key_flag == 0)
		return 0;
		else
		{
			//			_delay_ms(10);
			key_flag = 0;
			return 0;
		}
	}
	else							// if key input, check continuous key
	{
		if(key_flag != 0)			// if continuous key, treat as no key input
		return 0;
		else						// if new key, beep and delay for debounce
		{
			//			_delay_ms(10);
			key_flag = 1;
			if(key == 0x10) key = 1;
			else if(key == 0x20) key = 2;
			else if(key == 0x40) key = 3;
			else if(key == 0x80) key = 4;
			return key;
		}
	}
}

void led_control()
{
	if( auto_mode )	// 스마트홈 모드
	{
		if( cds_val <= 75 )
		{
			PORTA = 0x0f;
		}
		else
		{
			PORTA = bit_clear(PORTA,PORTA0);
			PORTA = bit_clear(PORTA,PORTA1);
			PORTA = bit_clear(PORTA,PORTA2);
			PORTA = bit_clear(PORTA,PORTA3);
		}
	}
	 
}

void fan_control()
{
	if ( auto_mode )	//스마트 모드
	{
		if( temp_val > 26 )
		{
			//PORTF = bit_set(PORTF,PORTF0);
			fan_state = 1;
		}
		
		else if ( temp_val <= 26 )
		{
			//PORTF = bit_clear(PORTF,PORTF0);
			//PORTF = bit_set(PORTF,PORTF0);
			fan_state = 0;
		}
		
	}
	
	if (fan_state)
	{
		PORTF = bit_set(PORTF,PORTF0);
	}
	else
	{
		PORTF = bit_clear(PORTF,PORTF0);
	}
}


void motor_control()
{
	if ( home_mode )	//불났을 경우 스프링 쿨러
	{
		bit_set(MOTOR_PORT,MOTOR_LEFT_ENABLE);
		bit_clear(MOTOR_PORT,MOTOR_RIGHT_ENABLE);
	}
	else //불났을 경우 스프링 쿨러 해제
	{
		bit_clear(MOTOR_PORT,MOTOR_LEFT_ENABLE);
		bit_clear(MOTOR_PORT,MOTOR_RIGHT_ENABLE);
	}
}
